package io.odomia.odoseal

import android.Manifest
import android.bluetooth.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.util.*

/**
 * OdoSeal Beta — Main Activity
 * OBD-II → Odokey (IPFS + AES-256) → Solana
 * Odocar LLC © 2026
 */
class MainActivity : AppCompatActivity() {

    // ── Bluetooth ────────────────────────────────────────────────
    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    // Standard SPP UUID for OBD-II adapters (ELM327)
    private val OBD_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── Odokey API ───────────────────────────────────────────────
    private val ODOKEY_ENDPOINT = "https://odokey.odomia.io/store"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkPermissions()
    }

    // ── Permissions ──────────────────────────────────────────────
    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        ActivityCompat.requestPermissions(this, permissions, 100)
    }

    // ── Connect to OBD-II device ─────────────────────────────────
    fun connectToOBD(deviceAddress: String) {
        scope.launch {
            try {
                val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                val device = bluetoothAdapter.getRemoteDevice(deviceAddress)

                bluetoothSocket = device.createRfcommSocketToServiceRecord(OBD_UUID)
                bluetoothSocket?.connect()

                inputStream  = bluetoothSocket?.inputStream
                outputStream = bluetoothSocket?.outputStream

                Log.d("OdoSeal", "Connected to OBD-II device: $deviceAddress")

                // Initialize ELM327
                initializeELM327()

                // Start reading loop
                startReading()

            } catch (e: Exception) {
                Log.e("OdoSeal", "Connection failed: ${e.message}")
            }
        }
    }

    // ── Initialize ELM327 adapter ────────────────────────────────
    private suspend fun initializeELM327() {
        sendOBDCommand("ATZ")   // Reset
        delay(1000)
        sendOBDCommand("ATE0")  // Echo off
        delay(300)
        sendOBDCommand("ATL0")  // Linefeeds off
        delay(300)
        sendOBDCommand("ATSP0") // Auto protocol
        delay(300)
    }

    // ── Send OBD command ─────────────────────────────────────────
    private fun sendOBDCommand(command: String): String {
        outputStream?.write("$command\r".toByteArray())
        Thread.sleep(200)

        val buffer = ByteArray(1024)
        val bytes = inputStream?.read(buffer) ?: 0
        return String(buffer, 0, bytes).trim()
    }

    // ── Read vehicle data ────────────────────────────────────────
    private suspend fun startReading() {
        while (bluetoothSocket?.isConnected == true) {
            val data = readVehicleData()
            Log.d("OdoSeal", "Vehicle data: $data")

            // Upload to Odokey
            uploadToOdokey(data)

            delay(5000) // Read every 5 seconds
        }
    }

    // ── Read all OBD-II PIDs ─────────────────────────────────────
    private fun readVehicleData(): JSONObject {
        val data = JSONObject()

        try {
            // RPM — PID 010C
            val rpmRaw = sendOBDCommand("010C")
            data.put("rpm", parseRPM(rpmRaw))

            // Vehicle Speed — PID 010D
            val speedRaw = sendOBDCommand("010D")
            data.put("speed_kmh", parseSpeed(speedRaw))

            // Engine Coolant Temp — PID 0105
            val tempRaw = sendOBDCommand("0105")
            data.put("coolant_temp_c", parseTemp(tempRaw))

            // Throttle Position — PID 0111
            val throttleRaw = sendOBDCommand("0111")
            data.put("throttle_pct", parseThrottle(throttleRaw))

            // DTC codes — PID 03
            val dtcRaw = sendOBDCommand("03")
            data.put("dtc_codes", dtcRaw)

            // Metadata
            data.put("timestamp", System.currentTimeMillis())
            data.put("source", "odoseal-beta")
            data.put("version", "1.0.0")

        } catch (e: Exception) {
            Log.e("OdoSeal", "Read error: ${e.message}")
        }

        return data
    }

    // ── OBD-II Parsers ───────────────────────────────────────────

    private fun parseRPM(raw: String): Int {
        return try {
            val bytes = raw.replace("410C", "").trim().split(" ")
            if (bytes.size >= 2) {
                ((bytes[0].toInt(16) * 256) + bytes[1].toInt(16)) / 4
            } else 0
        } catch (e: Exception) { 0 }
    }

    private fun parseSpeed(raw: String): Int {
        return try {
            raw.replace("410D", "").trim().split(" ")[0].toInt(16)
        } catch (e: Exception) { 0 }
    }

    private fun parseTemp(raw: String): Int {
        return try {
            raw.replace("4105", "").trim().split(" ")[0].toInt(16) - 40
        } catch (e: Exception) { 0 }
    }

    private fun parseThrottle(raw: String): Int {
        return try {
            (raw.replace("4111", "").trim().split(" ")[0].toInt(16) * 100) / 255
        } catch (e: Exception) { 0 }
    }

    // ── Upload to Odokey ─────────────────────────────────────────
    private fun uploadToOdokey(data: JSONObject) {
        scope.launch {
            try {
                val url = java.net.URL(ODOKEY_ENDPOINT)
                val connection = url.openConnection() as java.net.HttpURLConnection

                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true

                val payload = JSONObject()
                payload.put("data", data.toString())
                payload.put("encrypted", true)
                payload.put("chain", "solana")

                connection.outputStream.write(payload.toString().toByteArray())

                val responseCode = connection.responseCode
                if (responseCode == 200) {
                    val response = connection.inputStream.bufferedReader().readText()
                    val json = JSONObject(response)
                    val cid = json.getString("cid")
                    Log.d("OdoSeal", "✅ Stored on Odokey — CID: $cid")
                }

                connection.disconnect()

            } catch (e: Exception) {
                Log.e("OdoSeal", "Upload failed: ${e.message}")
            }
        }
    }

    // ── Cleanup ──────────────────────────────────────────────────
    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        bluetoothSocket?.close()
    }
}
