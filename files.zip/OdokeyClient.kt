package io.odomia.odoseal

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.security.SecureRandom
import android.util.Base64

/**
 * OdokeyClient — AES-256-GCM encryption + IPFS storage
 * Connects to Odokey server → pins to IPFS
 * Odocar LLC © 2026
 */
class OdokeyClient(
    private val endpoint: String = "https://odokey.odomia.io",
    private val aesKey: ByteArray                              // 32 bytes
) {

    companion object {
        private const val TAG = "OdokeyClient"
        private const val AES_MODE = "AES/GCM/NoPadding"
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128
    }

    // ── Encrypt with AES-256-GCM ─────────────────────────────────
    fun encrypt(plaintext: String): EncryptedPayload {
        val iv = ByteArray(GCM_IV_LENGTH).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance(AES_MODE)
        val keySpec = SecretKeySpec(aesKey, "AES")
        val paramSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)

        cipher.init(Cipher.ENCRYPT_MODE, keySpec, paramSpec)
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))

        return EncryptedPayload(
            iv   = Base64.encodeToString(iv, Base64.NO_WRAP),
            data = Base64.encodeToString(ciphertext, Base64.NO_WRAP)
        )
    }

    // ── Store to Odokey ──────────────────────────────────────────
    suspend fun store(vehicleData: VehicleData): OdokeyResponse? {
        return withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("rpm",          vehicleData.rpm)
                    put("speed_kmh",    vehicleData.speedKmh)
                    put("coolant_temp", vehicleData.coolantTempC)
                    put("throttle",     vehicleData.throttlePct)
                    put("dtc",          vehicleData.dtcCodes)
                    put("timestamp",    vehicleData.timestamp)
                    put("device_id",    vehicleData.deviceId)
                    put("source",       vehicleData.source)
                }

                val encrypted = encrypt(json.toString())

                val payload = JSONObject().apply {
                    put("iv",        encrypted.iv)
                    put("data",      encrypted.data)
                    put("encrypted", true)
                    put("chain",     "solana")
                }

                val url = URL("$endpoint/store")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.outputStream.write(payload.toString().toByteArray())

                if (conn.responseCode == 200) {
                    val response = JSONObject(conn.inputStream.bufferedReader().readText())
                    val cid = response.getString("cid")
                    Log.d(TAG, "✅ Stored — CID: $cid")
                    OdokeyResponse(
                        cid       = cid,
                        encrypted = true,
                        timestamp = System.currentTimeMillis()
                    )
                } else {
                    Log.e(TAG, "Store failed: ${conn.responseCode}")
                    null
                }

            } catch (e: Exception) {
                Log.e(TAG, "Store error: ${e.message}")
                null
            }
        }
    }
}

data class EncryptedPayload(
    val iv:   String,
    val data: String
)
