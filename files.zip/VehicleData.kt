package io.odomia.odoseal

/**
 * OdoSeal — Vehicle Data Model
 * Odocar LLC © 2026
 */
data class VehicleData(
    val rpm:           Int,
    val speedKmh:      Int,
    val coolantTempC:  Int,
    val throttlePct:   Int,
    val dtcCodes:      String,
    val timestamp:     Long,
    val deviceId:      String,
    val source:        String = "odoseal-beta",
    val version:       String = "1.0.0"
)

data class OdokeyResponse(
    val cid:       String,
    val encrypted: Boolean,
    val timestamp: Long
)

data class SolanaRecord(
    val txSignature: String,
    val cid:         String,
    val slot:        Long,
    val confirmed:   Boolean
)
