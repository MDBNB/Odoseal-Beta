package io.odomia.odoseal

import android.Manifest
import android.bluetooth.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.util.*

/**
 * OdoSeal Beta — Main Activity
 * Flow: OBD-II → Odokey (IPFS+AES256) → Solana
 * Odocar LLC © 2026
 */
class MainActivity : AppCompatActivity() {

    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    private val OBD_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── Clients ──────────────────────────────────────────────────
    private lateinit var odokeyClient: OdokeyClient
    private lateinit var solanaClient: SolanaClient

    // ── UI ───────────────────────────────────────────────────────
    private lateinit var tvStatus: TextView
    private lateinit var tvCID: TextView
    private lateinit var tvSolana: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvCID    = findViewById(R.id.tvCID)
        tvSolana = findViewById(R.id.tvSolana)

        // init clients
        odokeyClient = OdokeyClient(
            aesKey = getAESKey()
        )
        solanaClient = SolanaClient(
            walletPublicKey = getWalletPublicKey()
        )

        checkPermissions()
    }

    // ── Full pipeline ────────────────────────────────────────────
    private suspend fun runPipeline(deviceAddress: String) {

        // 1. Connect OBD-II
        updateStatus("🔌 Connecting to OBD-II...")
        connectToOBD(deviceAddress)

        // 2. Read vehicle data
        updateStatus("📡 Reading vehicle data...")
        val data = readVehicleData()

        val vehicleData = VehicleData(
            rpm          = data.getInt("rpm"),
            speedKmh     = data.getInt("speed_kmh"),
            coolantTempC = data.getInt("coolant_temp_c"),
            throttlePct  = data.getInt("throttle_pct"),
            dtcCodes     = data.getString("dtc_codes"),
            timestamp    = data.getLong("timestamp"),
            deviceId     = deviceAddress
        )

        // 3. Upload to Odokey (IPFS + AES-256)
        updateStatus("🔐 Encrypting & storing on Odokey...")
        val odokeyResult = odokeyClient.store(vehicleData)

        if (odokeyResult == null) {
            updateStatus("❌ Odokey upload failed")
            return
        }

        val cid = odokeyResult.cid
        runOnUiThread { tvCID.text = "CID: $cid" }
        Log.d("OdoSeal", "✅ Odokey CID: $cid")

        // 4. Write CID to Solana
        updateStatus("⛓️ Writing to Solana blockchain...")
        val solanaResult = solanaClient.recordCID(cid, vehicleData)

        if (solanaResult != null) {
            runOnUiThread {
                tvSolana.text = "TX: ${solanaResult.txSignature}"
                tvStatus.text = "✅ Verified on Solana"
            }
            Log.d("OdoSeal", "🔗 solscan.io/tx/${solanaResult.txSignature}")
        } else {
            updateStatus("⚠️ Stored on IPFS — Solana pending")
        }
    }

    // ── Connect Bluetooth OBD-II ─────────────────────────────────
    private fun connectToOBD(deviceAddress: String) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        val device  = adapter.getRemoteDevice(deviceAddress)
        bluetoothSocket = device.createRfcommSocketToServiceRecord(OBD_UUID)
        bluetoothSocket?.connect()
        inputStream  = bluetoothSocket?.inputStream
        outputStream = bluetoothSocket?.outputStream
        initializeELM327()
    }

    private fun initializeELM327() {
        sendCmd("ATZ");  Thread.sleep(1000)
        sendCmd("ATE0"); Thread.sleep(300)
        sendCmd("ATL0"); Thread.sleep(300)
        sendCmd("ATSP0"); Thread.sleep(300)
    }

    private fun sendCmd(cmd: String): String {
        outputStream?.write("$cmd\r".toByteArray())
        Thread.sleep(200)
        val buf = ByteArray(1024)
        val n = inputStream?.read(buf) ?: 0
        return String(buf, 0, n).trim()
    }

    // ── Read OBD-II PIDs ─────────────────────────────────────────
    private fun readVehicleData(): JSONObject {
        val d = JSONObject()
        d.put("rpm",           parseRPM(sendCmd("010C")))
        d.put("speed_kmh",     parseSpeed(sendCmd("010D")))
        d.put("coolant_temp_c",parseTemp(sendCmd("0105")))
        d.put("throttle_pct",  parseThrottle(sendCmd("0111")))
        d.put("dtc_codes",     sendCmd("03"))
        d.put("timestamp",     System.currentTimeMillis())
        return d
    }

    private fun parseRPM(r: String) = try {
        val b = r.replace("410C","").trim().split(" ")
        ((b[0].toInt(16)*256)+b[1].toInt(16))/4
    } catch(e:Exception){0}

    private fun parseSpeed(r: String) = try {
        r.replace("410D","").trim().split(" ")[0].toInt(16)
    } catch(e:Exception){0}

    private fun parseTemp(r: String) = try {
        r.replace("4105","").trim().split(" ")[0].toInt(16)-40
    } catch(e:Exception){0}

    private fun parseThrottle(r: String) = try {
        (r.replace("4111","").trim().split(" ")[0].toInt(16)*100)/255
    } catch(e:Exception){0}

    // ── Helpers ──────────────────────────────────────────────────
    private fun updateStatus(msg: String) {
        runOnUiThread { tvStatus.text = msg }
        Log.d("OdoSeal", msg)
    }

    private fun getAESKey(): ByteArray {
        // في الإنتاج: احفظ المفتاح في Android Keystore
        val keyHex = "0000000000000000000000000000000000000000000000000000000000000000"
        return keyHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }

    private fun getWalletPublicKey(): String {
        // مفتاح محفظة Solana الخاص بالمستخدم
        return "YOUR_SOLANA_WALLET_PUBLIC_KEY"
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        bluetoothSocket?.close()
    }
}
