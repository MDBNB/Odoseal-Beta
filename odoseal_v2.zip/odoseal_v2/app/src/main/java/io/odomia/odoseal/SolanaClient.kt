package io.odomia.odoseal

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * SolanaClient — كتابة CID على Solana blockchain
 * بعد كل upload على Odokey، نكتب الـ CID على Solana
 * Odocar LLC © 2026
 */
class SolanaClient(
    private val rpcUrl: String = "https://api.mainnet-beta.solana.com",
    private val walletPublicKey: String  // مفتاح محفظتك العام
) {

    companion object {
        private const val TAG = "SolanaClient"
        // OdoSeal Program ID على Solana (تغيره بعد deploy)
        const val PROGRAM_ID = "OdoSeaL1111111111111111111111111111111111111"
    }

    // ── كتابة CID على Solana عبر Odomia Backend ─────────────────
    // نستخدم Odomia backend عشان يوقع الـ transaction
    // (التوقيع يحتاج private key — ما نحطه في التطبيق)
    suspend fun recordCID(
        cid: String,
        vehicleData: VehicleData
    ): SolanaRecord? {
        return withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject().apply {
                    put("cid",        cid)
                    put("wallet",     walletPublicKey)
                    put("rpm",        vehicleData.rpm)
                    put("speed",      vehicleData.speedKmh)
                    put("timestamp",  vehicleData.timestamp)
                    put("device_id",  vehicleData.deviceId)
                    put("program_id", PROGRAM_ID)
                }

                val url = URL("https://api.odomia.io/solana/record")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.outputStream.write(payload.toString().toByteArray())

                if (conn.responseCode == 200) {
                    val response = JSONObject(
                        conn.inputStream.bufferedReader().readText()
                    )
                    val tx = response.getString("signature")
                    val slot = response.getLong("slot")

                    Log.d(TAG, "✅ On-chain — TX: $tx")
                    Log.d(TAG, "🔗 https://solscan.io/tx/$tx")

                    SolanaRecord(
                        txSignature = tx,
                        cid         = cid,
                        slot        = slot,
                        confirmed   = true
                    )
                } else {
                    Log.e(TAG, "Solana record failed: ${conn.responseCode}")
                    null
                }

            } catch (e: Exception) {
                Log.e(TAG, "Solana error: ${e.message}")
                null
            }
        }
    }

    // ── تحقق من وجود السجل على Solana ───────────────────────────
    suspend fun verifyCID(cid: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL("https://api.odomia.io/solana/verify?cid=$cid")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"

                if (conn.responseCode == 200) {
                    val response = JSONObject(
                        conn.inputStream.bufferedReader().readText()
                    )
                    response.getBoolean("verified")
                } else false

            } catch (e: Exception) {
                Log.e(TAG, "Verify error: ${e.message}")
                false
            }
        }
    }
}
